#!/bin/sh
exec /usr/bin/fakeroot /usr/bin/dpkg $*
