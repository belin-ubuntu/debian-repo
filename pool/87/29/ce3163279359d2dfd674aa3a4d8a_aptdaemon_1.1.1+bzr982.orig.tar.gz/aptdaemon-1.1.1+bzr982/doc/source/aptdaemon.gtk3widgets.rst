:mod:`aptdaemon.gtk3widgets` --- The gtk3widgets module
=====================================================

.. automodule:: aptdaemon.gtk3widgets
    :members:
